import { motion } from "framer-motion";
import { Activity, Clock } from "lucide-react";
import { useState, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";

const generateData = () => {
  return Array.from({ length: 20 }, (_, i) => ({
    time: `${i}s`,
    ph: 6.8 + Math.random() * 0.6,
    temp: 24 + Math.random() * 3,
    tds: 280 + Math.random() * 60,
  }));
};

const WaterQualityChart = () => {
  const [data, setData] = useState(generateData);

  useEffect(() => {
    const interval = setInterval(() => {
      setData((prev) => {
        const newPoint = {
          time: `${prev.length}s`,
          ph: 6.8 + Math.random() * 0.6,
          temp: 24 + Math.random() * 3,
          tds: 280 + Math.random() * 60,
        };
        return [...prev.slice(1), newPoint];
      });
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="glass-card p-6"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display text-lg font-semibold text-foreground tracking-wide flex items-center gap-2">
          <Activity className="w-5 h-5 text-primary" />
          Live Monitoring
        </h3>
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <Clock className="w-3.5 h-3.5" />
          Real-time
        </div>
      </div>
      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <XAxis dataKey="time" tick={{ fontSize: 10, fill: "hsl(210 20% 55%)" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: "hsl(210 20% 55%)" }} axisLine={false} tickLine={false} />
            <Tooltip
              contentStyle={{
                background: "hsl(215 30% 10%)",
                border: "1px solid hsl(215 25% 18%)",
                borderRadius: "8px",
                fontSize: "12px",
                color: "hsl(195 100% 95%)",
              }}
            />
            <Line type="monotone" dataKey="ph" stroke="hsl(185 80% 50%)" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="temp" stroke="hsl(38 92% 50%)" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="flex gap-4 mt-3 justify-center">
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-0.5 rounded-full bg-primary" />
          <span className="text-xs text-muted-foreground">pH</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-0.5 rounded-full bg-warning" />
          <span className="text-xs text-muted-foreground">Temp</span>
        </div>
      </div>
    </motion.div>
  );
};

export default WaterQualityChart;
