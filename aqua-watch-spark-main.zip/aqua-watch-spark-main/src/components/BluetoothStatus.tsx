import { motion, AnimatePresence } from "framer-motion";
import { Bluetooth, BluetoothConnected, Wifi, Search, X } from "lucide-react";
import { useState, useEffect } from "react";

interface Device {
  id: string;
  name: string;
  rssi: number;
}

const mockDevices: Device[] = [
  { id: "d1", name: "AquaSensor-X1", rssi: -42 },
  { id: "d2", name: "WaterProbe-M3", rssi: -67 },
  { id: "d3", name: "HydroSense-V2", rssi: -78 },
];

const BluetoothStatus = () => {
  const [scanning, setScanning] = useState(false);
  const [devices, setDevices] = useState<Device[]>([]);
  const [connectedDevice, setConnectedDevice] = useState<Device | null>(null);
  const [signalStrength, setSignalStrength] = useState(0);
  const [showPanel, setShowPanel] = useState(false);

  const startScan = () => {
    setScanning(true);
    setDevices([]);
    // Simulate devices appearing one by one
    mockDevices.forEach((device, i) => {
      setTimeout(() => {
        setDevices((prev) => [...prev, device]);
      }, 800 + i * 600);
    });
    setTimeout(() => setScanning(false), 3000);
  };

  const connectDevice = (device: Device) => {
    setConnectedDevice(device);
    setShowPanel(false);
  };

  const disconnect = () => {
    setConnectedDevice(null);
    setDevices([]);
  };

  useEffect(() => {
    if (!connectedDevice) return;
    const interval = setInterval(() => {
      setSignalStrength(70 + Math.random() * 25);
    }, 1500);
    return () => clearInterval(interval);
  }, [connectedDevice]);

  return (
    <div className="relative">
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="glass-card p-4 flex items-center gap-4 cursor-pointer"
        onClick={() => !connectedDevice && setShowPanel(!showPanel)}
      >
        <div className={`p-3 rounded-xl ${connectedDevice ? "bg-success/20 animate-pulse-glow" : "bg-muted"}`}>
          {connectedDevice ? (
            <BluetoothConnected className="w-5 h-5 text-success" />
          ) : (
            <Bluetooth className="w-5 h-5 text-muted-foreground" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-display font-medium text-foreground tracking-wide">
            {connectedDevice ? connectedDevice.name : "Tap to Scan"}
          </p>
          <p className="text-xs text-muted-foreground">
            {connectedDevice ? "Bluetooth LE Connected" : "No device connected"}
          </p>
        </div>
        {connectedDevice ? (
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <Wifi className="w-4 h-4 text-success" />
              <span className="text-xs font-mono text-success">{signalStrength.toFixed(0)}%</span>
            </div>
            <button
              onClick={(e) => { e.stopPropagation(); disconnect(); }}
              className="p-1 rounded-lg hover:bg-destructive/20 transition-colors"
            >
              <X className="w-4 h-4 text-destructive" />
            </button>
          </div>
        ) : (
          <Search className="w-4 h-4 text-muted-foreground" />
        )}
      </motion.div>

      {/* Scan Panel */}
      <AnimatePresence>
        {showPanel && !connectedDevice && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.95 }}
            className="absolute top-full left-0 right-0 mt-2 glass-card p-4 z-50"
          >
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-display font-semibold text-foreground tracking-wide">
                Nearby Devices
              </h4>
              <button
                onClick={startScan}
                disabled={scanning}
                className="text-xs font-display font-medium px-3 py-1.5 rounded-lg bg-primary/20 text-primary hover:bg-primary/30 transition-colors disabled:opacity-50"
              >
                {scanning ? "Scanning..." : "Scan"}
              </button>
            </div>

            {scanning && devices.length === 0 && (
              <div className="flex items-center justify-center gap-2 py-4">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                >
                  <Bluetooth className="w-5 h-5 text-primary" />
                </motion.div>
                <span className="text-xs text-muted-foreground">Searching for devices...</span>
              </div>
            )}

            <div className="space-y-2">
              <AnimatePresence>
                {devices.map((device) => (
                  <motion.button
                    key={device.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0 }}
                    onClick={() => connectDevice(device)}
                    className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:border-primary/50 hover:bg-primary/5 transition-all text-left"
                  >
                    <Bluetooth className="w-4 h-4 text-primary shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground">{device.name}</p>
                      <p className="text-[10px] text-muted-foreground">Signal: {device.rssi} dBm</p>
                    </div>
                    <span className="text-[10px] font-display font-semibold uppercase tracking-widest text-primary">
                      Connect
                    </span>
                  </motion.button>
                ))}
              </AnimatePresence>
            </div>

            {!scanning && devices.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-3">
                Tap "Scan" to find nearby sensors
              </p>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default BluetoothStatus;
