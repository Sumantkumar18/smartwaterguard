import { motion } from "framer-motion";
import { Droplets, FlaskConical } from "lucide-react";
import { useState } from "react";

interface Sample {
  id: string;
  name: string;
  source: string;
  status: "safe" | "warning" | "danger";
}

const samples: Sample[] = [
  { id: "S1", name: "Sample A", source: "Municipal Supply", status: "safe" },
  { id: "S2", name: "Sample B", source: "Borewell Water", status: "warning" },
  { id: "S3", name: "Sample C", source: "River Source", status: "danger" },
];

interface Props {
  onSelect: (id: string) => void;
  selected: string;
}

const statusLabel = {
  safe: { text: "Potable", className: "bg-success/20 text-success" },
  warning: { text: "Caution", className: "bg-warning/20 text-warning" },
  danger: { text: "Unsafe", className: "bg-destructive/20 text-destructive" },
};

const WaterSampleSelector = ({ onSelect, selected }: Props) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className="glass-card p-4"
    >
      <h3 className="font-display text-sm font-semibold text-foreground tracking-wide mb-3 flex items-center gap-2">
        <FlaskConical className="w-4 h-4 text-primary" />
        Water Samples
      </h3>
      <div className="grid grid-cols-3 gap-2">
        {samples.map((sample) => {
          const isActive = selected === sample.id;
          const label = statusLabel[sample.status];
          return (
            <button
              key={sample.id}
              onClick={() => onSelect(sample.id)}
              className={`p-3 rounded-lg border text-left transition-all ${
                isActive
                  ? "border-primary bg-primary/10 glow-primary"
                  : "border-border hover:border-primary/50 bg-muted/30"
              }`}
            >
              <div className="flex items-center gap-1.5 mb-1">
                <Droplets className={`w-3.5 h-3.5 ${isActive ? "text-primary" : "text-muted-foreground"}`} />
                <span className="text-xs font-display font-semibold text-foreground">{sample.name}</span>
              </div>
              <p className="text-[10px] text-muted-foreground mb-1.5">{sample.source}</p>
              <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full ${label.className}`}>
                {label.text}
              </span>
            </button>
          );
        })}
      </div>
    </motion.div>
  );
};

export default WaterSampleSelector;
