import { motion } from "framer-motion";
import { AlertTriangle, ShieldCheck, ShieldAlert } from "lucide-react";

interface Disease {
  name: string;
  risk: "low" | "medium" | "high";
  cause: string;
}

const diseases: Disease[] = [
  { name: "Cholera", risk: "low", cause: "High bacterial contamination" },
  { name: "Typhoid", risk: "low", cause: "Salmonella in untreated water" },
  { name: "Dysentery", risk: "medium", cause: "Low pH & high turbidity" },
  { name: "Lead Poisoning", risk: "low", cause: "Heavy metal contamination" },
  { name: "Fluorosis", risk: "medium", cause: "Excess fluoride levels" },
  { name: "Hepatitis A", risk: "low", cause: "Viral waterborne pathogen" },
];

const riskConfig = {
  low: { color: "text-success", bg: "bg-success/10", border: "border-success/30", icon: ShieldCheck },
  medium: { color: "text-warning", bg: "bg-warning/10", border: "border-warning/30", icon: AlertTriangle },
  high: { color: "text-destructive", bg: "bg-destructive/10", border: "border-destructive/30", icon: ShieldAlert },
};

const DiseaseWarnings = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="glass-card p-6"
    >
      <h3 className="font-display text-lg font-semibold text-foreground tracking-wide mb-4 flex items-center gap-2">
        <ShieldAlert className="w-5 h-5 text-primary" />
        Disease Risk Analysis
      </h3>
      <div className="grid gap-3">
        {diseases.map((disease, i) => {
          const config = riskConfig[disease.risk];
          const Icon = config.icon;
          return (
            <motion.div
              key={disease.name}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 + i * 0.08 }}
              className={`flex items-center gap-3 p-3 rounded-lg border ${config.bg} ${config.border}`}
            >
              <Icon className={`w-4 h-4 ${config.color} shrink-0`} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground">{disease.name}</p>
                <p className="text-xs text-muted-foreground truncate">{disease.cause}</p>
              </div>
              <span className={`text-xs font-display font-bold uppercase tracking-widest ${config.color}`}>
                {disease.risk}
              </span>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
};

export default DiseaseWarnings;
