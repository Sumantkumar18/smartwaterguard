import { motion } from "framer-motion";

interface GaugeProps {
  value: number;
  max: number;
  min: number;
  label: string;
  unit: string;
  status: "safe" | "warning" | "danger";
  icon: React.ReactNode;
}

const statusColors = {
  safe: { stroke: "hsl(152 69% 45%)", glow: "glow-accent" },
  warning: { stroke: "hsl(38 92% 50%)", glow: "glow-warning" },
  danger: { stroke: "hsl(0 72% 51%)", glow: "glow-danger" },
};

const SensorGauge = ({ value, max, min, label, unit, status, icon }: GaugeProps) => {
  const percentage = Math.min(((value - min) / (max - min)) * 100, 100);
  const dashOffset = 283 - (283 * percentage) / 100;
  const colors = statusColors[status];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`glass-card p-6 flex flex-col items-center gap-3 ${colors.glow}`}
    >
      <div className="relative w-28 h-28">
        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
          <circle
            cx="50" cy="50" r="45"
            fill="none"
            stroke="hsl(215 25% 18%)"
            strokeWidth="6"
          />
          <motion.circle
            cx="50" cy="50" r="45"
            fill="none"
            stroke={colors.stroke}
            strokeWidth="6"
            className="gauge-ring"
            initial={{ strokeDashoffset: 283 }}
            animate={{ strokeDashoffset: dashOffset }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-display font-bold text-foreground">
            {value.toFixed(1)}
          </span>
          <span className="text-xs text-muted-foreground">{unit}</span>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {icon}
        <span className="text-sm font-display font-medium tracking-wider uppercase text-secondary-foreground">
          {label}
        </span>
      </div>
      <span
        className={`text-xs font-semibold uppercase tracking-widest px-3 py-1 rounded-full ${
          status === "safe"
            ? "bg-success/20 text-success"
            : status === "warning"
            ? "bg-warning/20 text-warning"
            : "bg-destructive/20 text-destructive"
        }`}
      >
        {status}
      </span>
    </motion.div>
  );
};

export default SensorGauge;
