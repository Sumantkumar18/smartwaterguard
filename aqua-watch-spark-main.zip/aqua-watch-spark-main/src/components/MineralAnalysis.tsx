import { motion } from "framer-motion";
import { Beaker } from "lucide-react";

interface Mineral {
  name: string;
  value: number;
  unit: string;
  safe: number;
  max: number;
}

const minerals: Mineral[] = [
  { name: "Calcium (Ca²⁺)", value: 42, unit: "mg/L", safe: 75, max: 200 },
  { name: "Magnesium (Mg²⁺)", value: 18, unit: "mg/L", safe: 30, max: 100 },
  { name: "Sodium (Na⁺)", value: 85, unit: "mg/L", safe: 200, max: 400 },
  { name: "Iron (Fe)", value: 0.12, unit: "mg/L", safe: 0.3, max: 1 },
  { name: "Fluoride (F⁻)", value: 1.8, unit: "mg/L", safe: 1.5, max: 4 },
  { name: "Chloride (Cl⁻)", value: 120, unit: "mg/L", safe: 250, max: 600 },
  { name: "Nitrate (NO₃⁻)", value: 8, unit: "mg/L", safe: 45, max: 100 },
  { name: "Lead (Pb)", value: 0.005, unit: "mg/L", safe: 0.01, max: 0.05 },
];

const MineralAnalysis = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="glass-card p-6"
    >
      <h3 className="font-display text-lg font-semibold text-foreground tracking-wide mb-4 flex items-center gap-2">
        <Beaker className="w-5 h-5 text-primary" />
        Mineral & Impurity Analysis
      </h3>
      <div className="space-y-3">
        {minerals.map((mineral, i) => {
          const percentage = (mineral.value / mineral.max) * 100;
          const isOverSafe = mineral.value > mineral.safe;
          return (
            <motion.div
              key={mineral.name}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + i * 0.06 }}
            >
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-secondary-foreground">{mineral.name}</span>
                <span className={`text-xs font-mono font-semibold ${isOverSafe ? "text-warning" : "text-success"}`}>
                  {mineral.value} {mineral.unit}
                </span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${percentage}%` }}
                  transition={{ duration: 1, delay: 0.4 + i * 0.06 }}
                  className={`h-full rounded-full ${isOverSafe ? "bg-warning" : "bg-primary"}`}
                />
              </div>
              <div className="flex justify-between mt-0.5">
                <span className="text-[10px] text-muted-foreground">0</span>
                <span className="text-[10px] text-muted-foreground">Safe: {mineral.safe}</span>
                <span className="text-[10px] text-muted-foreground">{mineral.max}</span>
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
};

export default MineralAnalysis;
